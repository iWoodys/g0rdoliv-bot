import os
TOKEN = os.environ["DISCORD_TOKEN"]